const cells = Array.from(document.querySelectorAll('.cell')); const game = document.getElementById('game'); let board = ['', '', '', '', '', '', '', '', '']; let currentPlayer = 'X'; let gameMode = ''; let gameOver = false; function initializeGame() { gameMode = prompt('¿Quieres jugar contra la máquina (m) o contra un amigo (a)?').toLowerCase(); if (gameMode !== 'm' && gameMode !== 'a') { alert('Modo de juego inválido. Se jugará contra un amigo por defecto.'); gameMode = 'a'; } board = ['', '', '', '', '', '', '', '', '']; currentPlayer = 'X'; gameOver = false; renderBoard(); } function renderBoard() { game.innerHTML = ''; for (let i = 0; i < 9; i++) { const cell = document.createElement('div'); cell.classList.add('cell'); cell.textContent = board[i]; cell.addEventListener('click', () => handleClick(i)); game.appendChild(cell); } } function handleClick(index) { if (gameOver || board[index] !== '') return; board[index] = currentPlayer; if (checkWin()) { gameOver = true; alert(`${currentPlayer} gana!`); initializeGame(); return; } if (checkDraw()) { gameOver = true; alert('Empate!'); initializeGame(); return; } currentPlayer = currentPlayer === 'X' ? 'O' : 'X'; if(gameMode === 'm' && currentPlayer === 'O') { handleComputerTurn();} renderBoard(); } function checkWin() { const winPatterns = [ [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6] ]; for (const pattern of winPatterns) { if (board[pattern[0]] !== '' && board[pattern[0]] === board[pattern[1]] && board[pattern[0]] === board[pattern[2]]) { return true; } } return false; } function checkDraw() { return board.every(cell => cell !== ''); } function handleComputerTurn() { let bestScore = -Infinity;
  let bestMove;
  function evaluateBoard() {
  // Implementa tu lógica de puntuación aquí.  Ejemplo simple:
  let score = 0;
  // ... (código para evaluar líneas, columnas y diagonales) ...
  return score;
}
  for (let i = 0; i < 9; i++) {
    if (board[i] === '') {
      board[i] = 'O';
      let score = evaluateBoard();
      board[i] = ''; //Deshacer el movimiento para probar otros
      if (score > bestScore) {
        bestScore = score;
        bestMove = i;
      }
    }
  }
 handleClick(bestMove); currentPlayer = "X"; } initializeGame();