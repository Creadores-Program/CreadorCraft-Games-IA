const choices = document.getElementById('choices');
const result = document.getElementById('result');

const options = ['piedra', 'papel', 'tijera'];

choices.addEventListener('click', (event) => {
  if (event.target.tagName === 'BUTTON') {
    const playerChoice = event.target.id;
    const computerChoice = options[Math.floor(Math.random() * options.length)];

    let outcome = '';
    if (playerChoice === computerChoice) {
      outcome = 'Empate!';
    } else if (
      (playerChoice === 'piedra' && computerChoice === 'tijera') ||
      (playerChoice === 'papel' && computerChoice === 'piedra') ||
      (playerChoice === 'tijera' && computerChoice === 'papel')
    ) {
      outcome = '¡Ganaste!';
    } else {
      outcome = '¡Perdiste!';
    }

    result.textContent = `Elegiste ${playerChoice}, la computadora eligió ${computerChoice}. ${outcome}`;
  }
});