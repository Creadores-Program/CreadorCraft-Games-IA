const emojis = ['😀', '😂', '😍', '😎', '😋', '😡', '🤯', '🤔', '👍', '👎'];
const game = document.getElementById('game');
let cards = [];
let flippedCards = [];

function createCards() {
  const pairs = emojis.slice(0, 6).concat(emojis.slice(0, 6));
  pairs.sort(() => Math.random() - 0.5);

  pairs.forEach(emoji => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.addEventListener('click', flipCard);
    card.dataset.emoji = emoji;
    game.appendChild(card);
    cards.push(card);
  });
}

function flipCard() {
  if (flippedCards.length < 2 && !flippedCards.includes(this)) {
    this.classList.add('flipped');
    this.textContent = this.dataset.emoji;
    flippedCards.push(this);
    if (flippedCards.length === 2) {
      checkMatch();
    }
  }
}

function checkMatch() {
  if (flippedCards[0].dataset.emoji === flippedCards[1].dataset.emoji) {
    flippedCards.forEach(card => card.removeEventListener('click', flipCard));
    flippedCards = [];
    checkWin();
  } else {
    setTimeout(() => {
      flippedCards.forEach(card => {
        card.classList.remove('flipped');
        card.textContent = '';
      });
      flippedCards = [];
    }, 1000);
  }
}

function checkWin() {
  if (cards.every(card => card.classList.contains('flipped'))) {
    alert('¡Ganaste!');
    location.reload();
  }
}

createCards();