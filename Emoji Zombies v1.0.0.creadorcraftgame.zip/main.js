const gameBoard = document.getElementById('game-board');
const controls = document.getElementById('controls');
const playerSelection = document.getElementById('player-selection');
const roundNumberDisplay = document.getElementById('round-number');
const zombiesLeftDisplay = document.getElementById('zombies-left');
const playerHealthDisplay = document.getElementById('player-health');
const gameOverScreen = document.getElementById('game-over');
const restartButton = document.getElementById('restart-button');


let player = null;
let playerCharacter = '🧍';
let playerX = 50;
let playerY = 50;
let playerHealth = 10;

let zombies = [];
let round = 1;
let zombiesLeft = 0;

let zombieSpeed = 0.1;
let zombieStrength = 0.1;
let isGameOver = false;

let items = [];

const boardWidth = 400;
const boardHeight = 400;

function createCharacter(char, x, y, type) {
    const element = document.createElement('div');
    element.classList.add('character', type);
    element.textContent = char;
    element.style.left = x + 'px';
    element.style.top = y + 'px';
    gameBoard.appendChild(element);
    return element;
}

function updateCharacterPosition(element, x, y) {
    element.style.left = x + 'px';
    element.style.top = y + 'px';
}

function createZombie() {
  let zombieX, zombieY;
    do {
        zombieX = Math.random() * (boardWidth - 30);
      zombieY = Math.random() * (boardHeight - 30);
   } while (Math.abs(zombieX - playerX) < 50 && Math.abs(zombieY-playerY)<50);
    
    const zombieChar = Math.random() < 0.5 ? '🧟‍♂️' : '🧟‍♀️';
    const zombie = {
        element: createCharacter(zombieChar, zombieX, zombieY, 'zombie'),
        x: zombieX,
        y: zombieY,
        speed: zombieSpeed,
       strength: zombieStrength
    };
    zombies.push(zombie);
    zombiesLeft++;
    zombiesLeftDisplay.textContent = zombiesLeft;
}

function moveZombie(zombie) {
  const dx = playerX - zombie.x;
    const dy = playerY - zombie.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance > 0) {
        const moveX = (dx / distance) * zombie.speed;
        const moveY = (dy / distance) * zombie.speed;

        zombie.x += moveX;
        zombie.y += moveY;
        updateCharacterPosition(zombie.element, zombie.x, zombie.y);

        const collisionDistance = 20; 
        if (distance < collisionDistance) {
         playerHealth -= zombie.strength;
        if(playerHealth <= 0){
            playerHealth=0;
            gameOver();
          }
            playerHealthDisplay.textContent = playerHealth.toFixed(1);
        }
    }
}


function createItem(itemChar, x, y) {
    const item = document.createElement('div');
    item.classList.add('item');
    item.textContent = itemChar;
    item.style.left = x + 'px';
    item.style.top = y + 'px';
    gameBoard.appendChild(item);
     items.push({
        element: item,
        x: x,
        y: y,
        type: itemChar
    });
    setTimeout(()=>{
       items= items.filter(i=>i.element !== item);
        item.remove();
   }, 5000);
}

function useItem(itemType){
  if(itemType == '⚔️'){
        for (let i = zombies.length - 1; i >= 0; i--) {
           const zombie = zombies[i];
          const dx = playerX - zombie.x;
          const dy = playerY - zombie.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if(distance < 50){
            zombie.element.remove();
             zombies.splice(i, 1);
              zombiesLeft--;
              zombiesLeftDisplay.textContent = zombiesLeft;
          }
      }
  }else if(itemType == '💣'){
        for (let i = zombies.length - 1; i >= 0; i--) {
          const zombie = zombies[i];
            const dx = playerX - zombie.x;
            const dy = playerY - zombie.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if(distance < 100){
               zombie.element.remove();
                 zombies.splice(i, 1);
                  zombiesLeft--;
                  zombiesLeftDisplay.textContent = zombiesLeft;
            }
        }
  }else if(itemType == '🏹'){
    for (let i = zombies.length - 1; i >= 0; i--) {
            const zombie = zombies[i];
            const dx = playerX - zombie.x;
            const dy = playerY - zombie.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if(distance < 150){
                zombie.element.remove();
                 zombies.splice(i, 1);
                  zombiesLeft--;
                  zombiesLeftDisplay.textContent = zombiesLeft;
            }
        }
  }
}

function checkRoundEnd() {
  if (zombiesLeft <= 0) {
        round++;
        roundNumberDisplay.textContent = round;
        zombieSpeed += 0.1;
        zombieStrength += 0.1;
         const numZombies = Math.ceil(round * 2);
        for (let i = 0; i < numZombies; i++) {
            createZombie();
        }
    }
}

function gameLoop() {
    if(isGameOver) return;
    zombies.forEach(moveZombie);
    checkRoundEnd();
    requestAnimationFrame(gameLoop);
}

function handleMove(dx, dy) {
    playerX += dx * 5;
    playerY += dy * 5;

    playerX = Math.max(0, Math.min(playerX, boardWidth - 30));
    playerY = Math.max(0, Math.min(playerY, boardHeight - 30));

   updateCharacterPosition(player.element, playerX, playerY);
}

function gameOver(){
    isGameOver = true;
    gameOverScreen.style.display = 'block';
}

function restartGame(){
  isGameOver = false;
  gameOverScreen.style.display = 'none';
    playerHealth = 10;
    playerHealthDisplay.textContent = playerHealth;
    playerX = 50;
    playerY = 50;
    zombies.forEach(zombie=>zombie.element.remove());
    zombies=[];
    zombiesLeft = 0;
     zombieSpeed = 0.1;
    zombieStrength = 0.1;
    round = 1;
     roundNumberDisplay.textContent = round;
   createPlayer();
    const numZombies = Math.ceil(round * 2);
     for (let i = 0; i < numZombies; i++) {
        createZombie();
     }
     gameLoop();
}

function createPlayer() {
 if(player) player.element.remove();
    player = {
        element: createCharacter(playerCharacter, playerX, playerY, 'player')
    };
}

playerSelection.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON') {
        playerCharacter = e.target.textContent;
        playerSelection.style.display = 'none';
        createPlayer();
        const numZombies = Math.ceil(round * 2);
          for (let i = 0; i < numZombies; i++) {
            createZombie();
           }
        gameLoop();
    }
});


controls.addEventListener('click', (e) => {
    if(isGameOver) return;
   if (e.target.id === 'up') {
        handleMove(0, -1);
    } else if (e.target.id === 'down') {
        handleMove(0, 1);
    } else if (e.target.id === 'left') {
       handleMove(-1, 0);
   } else if (e.target.id === 'right') {
        handleMove(1, 0);
    } else if (e.target.id === 'attack') {
        useItem('⚔️');
    } else if (e.target.id === 'bomb') {
      useItem('💣');
    } else if(e.target.id === 'bow'){
     useItem('🏹');
   }
});

document.addEventListener('keydown', (e) => {
  if(isGameOver) return;
   if (e.key === 'ArrowUp') {
        handleMove(0, -1);
    } else if (e.key === 'ArrowDown') {
        handleMove(0, 1);
    } else if (e.key === 'ArrowLeft') {
        handleMove(-1, 0);
    } else if (e.key === 'ArrowRight') {
       handleMove(1, 0);
   }else if(e.key === 'a'){
    useItem('⚔️');
  }else if(e.key === 's'){
    useItem('💣');
  }else if(e.key === 'd'){
   useItem('🏹');
  }
});

setInterval(()=>{if(isGameOver)return; createItem(Math.random() < 0.33 ? '⚔️' : Math.random() < 0.66? '💣':'🏹', Math.random() * (boardWidth - 30), Math.random() * (boardHeight - 30));},10000)

restartButton.addEventListener('click',restartGame)
