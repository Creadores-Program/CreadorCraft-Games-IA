let player;
let gameContainer;
let playerChar;
let obstacles = [];
let monsters = [];
let gameOverDiv;
let winGameDiv;
let isGameOver = false;
let isWinGame = false;
let playerX, playerY;

function startGame(character) {
    playerChar = character;
    document.getElementById('choose-player').style.display = 'none';
    initGame();
}

function initGame() {
    isGameOver = false;
    isWinGame = false;
    gameOverDiv = document.getElementById('game-over');
    gameOverDiv.style.display = 'none';
    winGameDiv = document.getElementById('win-game');
    winGameDiv.style.display = 'none';
    gameContainer = document.getElementById('game-container');
    gameContainer.innerHTML = '';
    playerX = 10; // Posición inicial en X
    playerY = 20; // Posición inicial en Y

    player = document.createElement('div');
    player.classList.add('player');
    player.textContent = playerChar; // Usar el personaje seleccionado
    player.style.left = playerX + 'px';
    player.style.top = playerY + 'px';
    gameContainer.appendChild(player);

    obstacles = [];
    monsters = [];
    createLevel();
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('touchstart', handleTouchStart, { passive: false });
    document.addEventListener('touchend', handleTouchEnd);
    document.addEventListener('touchcancel', handleTouchEnd);
    updateGame();
}

function createLevel() {
    // Montaña alta con obstáculos y monstruos
    for (let i = 0; i < 20; i++) {
        let obstacleY = i * 40 + 80;
        let obstacleX1 = Math.random() * 500 + 50; // Evitar bordes
        let obstacleX2 = Math.random() * 500 + 50; // Evitar bordes

        createObstacle(obstacleX1, obstacleY);
        if(i % 3 === 0) {
          createMonster(obstacleX2, obstacleY, getRandomMonster());
        }
    }
}

function getRandomMonster() {
    const monstersChars = ['👿', '👾', '👹', '👺', '🎃', '👻', '💀'];
    return monstersChars[Math.floor(Math.random() * monstersChars.length)];
}

function createObstacle(x, y) {
  const obstacle = document.createElement('div');
  obstacle.classList.add('obstacle');
  obstacle.style.left = x + 'px';
  obstacle.style.top = y + 'px';
  gameContainer.appendChild(obstacle);
  obstacles.push({ x, y, element: obstacle });
}

function createMonster(x, y, char) {
  const monster = document.createElement('div');
    monster.classList.add('monster');
    monster.textContent = char;
    monster.style.left = x + 'px';
    monster.style.top = y + 'px';
    gameContainer.appendChild(monster);
    monsters.push({ x, y, element: monster, initialX: x, direction: Math.random() > 0.5 ? 1 : -1 });
}


function handleKeyDown(e) {
    if (isGameOver || isWinGame) return;
    switch (e.key) {
        case 'ArrowLeft':
          movePlayer(-10,0);
          break;
        case 'ArrowRight':
          movePlayer(10,0);
          break;
         case 'ArrowDown':
          movePlayer(0,10);
          break;
        case 'ArrowUp':
          movePlayer(0,-10);
          break;
    }
}

let touchStartX = 0;
let touchStartY = 0;

function handleTouchStart(e) {
  if (isGameOver || isWinGame) return; 
  e.preventDefault();
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
}

function handleTouchEnd(e) {
  if (isGameOver || isWinGame) return; 
  if (!e.changedTouches || e.changedTouches.length === 0) return;
  e.preventDefault();
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const deltaX = touchEndX - touchStartX;
    const deltaY = touchEndY - touchStartY;

    if(Math.abs(deltaX) > Math.abs(deltaY)) {
        if (deltaX > 20) {
            movePlayer(10, 0);
        } else if (deltaX < -20) {
            movePlayer(-10, 0);
        }
     } else {
        if(deltaY > 20){
          movePlayer(0, 10);
        }else if(deltaY < -20){
          movePlayer(0, -10);
        }
    }
}

function movePlayer(x, y) {
    playerX += x;
    playerY += y;
    player.style.left = playerX + 'px';
    player.style.top = playerY + 'px';
}

function updateGame() {
  if (isGameOver || isWinGame) return;

  moveMonsters();

  checkCollisions();
    if (playerY > 360) {
        winGame();
    }
    requestAnimationFrame(updateGame);
}

function moveMonsters() {
    monsters.forEach(monster => {
        monster.x += monster.direction * 2;
        if (monster.x > 550 || monster.x < 0) {
            monster.direction *= -1;
        }
        monster.element.style.left = monster.x + 'px';
    });
}

function checkCollisions() {
  obstacles.forEach(obstacle => {
        if (
            playerX < obstacle.x + 40 &&
            playerX + 30 > obstacle.x &&
            playerY < obstacle.y + 40 &&
            playerY + 30 > obstacle.y
        ) {
            gameOver();
        }
   });
    monsters.forEach(monster => {
        if (
            playerX < monster.x + 30 &&
            playerX + 30 > monster.x &&
            playerY < monster.y + 30 &&
            playerY + 30 > monster.y
        ) {
            gameOver();
        }
    });
}

function gameOver() {
    isGameOver = true;
    document.removeEventListener('keydown', handleKeyDown);
    document.removeEventListener('touchstart', handleTouchStart);
    document.removeEventListener('touchend', handleTouchEnd);
    document.removeEventListener('touchcancel', handleTouchEnd);
    gameOverDiv.style.display = 'block';
}

function winGame() {
    isWinGame = true;
    document.removeEventListener('keydown', handleKeyDown);
    document.removeEventListener('touchstart', handleTouchStart);
    document.removeEventListener('touchend', handleTouchEnd);
    document.removeEventListener('touchcancel', handleTouchEnd);
    winGameDiv.style.display = 'block';
}

function resetGame() {
    initGame();
}
