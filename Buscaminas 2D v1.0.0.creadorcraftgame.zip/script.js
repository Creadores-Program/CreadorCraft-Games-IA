const gridSize = 9;
const numMines = 10;
let grid = [];
let flags = 0;
let gameStarted = false;
let gameOver = false;
let flagMode = false; // Variable para controlar el modo bandera

const game = document.getElementById('game');
const flagButton = document.getElementById('flagButton');

flagButton.addEventListener('click', toggleFlagMode);

function createGrid() {
    grid = Array.from({ length: gridSize }, () => Array(gridSize).fill(0));
    plantMines();
    game.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;

    for (let i = 0; i < gridSize; i++) {
        for (let j = 0; j < gridSize; j++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.addEventListener('click', () => handleClick(i, j));
            cell.addEventListener('contextmenu', (e) => handleRightClick(i, j, e));
            game.appendChild(cell);
        }
    }
}

function plantMines() {
    let minesPlanted = 0;
    while (minesPlanted < numMines) {
        const row = Math.floor(Math.random() * gridSize);
        const col = Math.floor(Math.random() * gridSize);
        if (grid[row][col] !== 'M') {
            grid[row][col] = 'M';
            minesPlanted++;
        }
    }
}

function handleClick(row, col) {
    if (gameOver || !gameStarted) {
        startGame();
    }

    const cell = game.children[row * gridSize + col];

    if (flagMode) { // Modo bandera activo
        toggleFlag(row, col, cell);
    } else { // Modo juego normal
        if (grid[row][col] === 'M') {
            gameOver = true;
            revealMines();
            alert('¡Game Over!');
            resetGame();
        } else {
            revealCell(row, col);
            checkWin();
        }
    }
}


function handleRightClick(row, col, e) {
    e.preventDefault();
    if (!gameOver) {
        const cell = game.children[row * gridSize + col];
        toggleFlag(row, col, cell);

    }
}

function toggleFlag(row, col, cell) {
    if (cell.classList.contains('flagged')) {
        cell.classList.remove('flagged');
        cell.textContent = ''; // Elimina el emoji
        flags--;
    } else {
        cell.classList.add('flagged');
        cell.textContent = '🚩'; // Añade el emoji
        flags++;
    }
}

function revealCell(row, col) {
    const cell = game.children[row * gridSize + col];
    if (!cell.classList.contains('revealed') && !cell.classList.contains('flagged')) {
        cell.classList.add('revealed');
        const adjMines = countAdjacentMines(row, col);
        if (adjMines > 0) {
            cell.textContent = adjMines;
        } else {
            revealAdjacentEmptyCells(row, col);
        }
    }
}

function revealAdjacentEmptyCells(row, col) {
    for (let i = Math.max(0, row - 1); i <= Math.min(gridSize - 1, row + 1); i++) {
        for (let j = Math.max(0, col - 1); j <= Math.min(gridSize - 1, col + 1); j++) {
            revealCell(i, j);
        }
    }
}

function countAdjacentMines(row, col) {
    let count = 0;
    for (let i = Math.max(0, row - 1); i <= Math.min(gridSize - 1, row + 1); i++) {
        for (let j = Math.max(0, col - 1); j <= Math.min(gridSize - 1, col + 1); j++) {
            if (grid[i][j] === 'M') {
                count++;
            }
        }
    }
    return count;
}

function revealMines() {
    for (let i = 0; i < gridSize; i++) {
        for (let j = 0; j < gridSize; j++) {
            if (grid[i][j] === 'M') {
                const cell = game.children[i * gridSize + j];
                if (!cell.classList.contains('flagged')) {
                    cell.classList.add('mine');
                }
            }
        }
    }
}

function checkWin() {
    let revealedCells = 0;
    for (let i = 0; i < gridSize; i++) {
        for (let j = 0; j < gridSize; j++) {
            const cell = game.children[i * gridSize + j];
            if (cell.classList.contains('revealed')) {
                revealedCells++;
            }
        }
    }
    if (revealedCells === gridSize * gridSize - numMines) {
        alert('¡Ganaste!');
        resetGame();
    }
}

function resetGame() {
    gameOver = false;
    gameStarted = false;
    flags = 0;
    flagMode = false; // Restablecer el modo bandera
    game.innerHTML = '';
    createGrid();
}

function startGame() {
    gameStarted = true;
}

function toggleFlagMode() {
    flagMode = !flagMode;
    flagButton.textContent = flagMode ? 'Modo Bandera Activado' : 'Modo Bandera Desactivado';
}

createGrid();