const gameBoard = document.getElementById('game');
const levelSelect = document.getElementById('level-select');
let currentLevel = 0; // Variable para controlar el nivel actual

const levels = [
  // 20 niveles de Sudoku, cada uno representado como una matriz de 9x9
  // Ejemplo de un nivel fácil:
  [[5, 3, 0, 0, 7, 0, 0, 0, 0],
   [6, 0, 0, 1, 9, 5, 0, 0, 0],
   [0, 9, 8, 0, 0, 0, 0, 6, 0],
   [8, 0, 0, 0, 6, 0, 0, 0, 3],
   [4, 0, 0, 8, 0, 3, 0, 0, 1],
   [7, 0, 0, 0, 2, 0, 0, 0, 6],
   [0, 6, 0, 0, 0, 0, 2, 8, 0],
   [0, 0, 0, 4, 1, 9, 0, 0, 5],
   [0, 0, 0, 0, 8, 0, 0, 7, 9]],
  [[1, 0, 0, 0, 2, 0, 0, 0, 3], [0, 2, 0, 3, 0, 4, 0, 5, 0], [0, 0, 3, 0, 0, 0, 4, 0, 0], [0, 3, 0, 4, 0, 5, 0, 6, 0], [2, 0, 0, 0, 1, 0, 0, 0, 4], [0, 4, 0, 5, 0, 6, 0, 7, 0], [0, 0, 4, 0, 0, 0, 5, 0, 0], [0, 5, 0, 6, 0, 7, 0, 8, 0], [3, 0, 0, 0, 8, 0, 0, 0, 1]],
  [[5, 1, 6, 8, 4, 9, 7, 3, 2], [3, 7, 2, 6, 1, 5, 4, 8, 9], [8, 9, 4, 7, 3, 2, 5, 6, 1], [1, 6, 8, 3, 7, 4, 2, 9, 5], [9, 4, 3, 2, 5, 6, 1, 7, 8], [7, 2, 5, 1, 9, 8, 3, 4, 6], [2, 3, 7, 9, 6, 1, 8, 5, 4], [6, 8, 9, 5, 2, 7, 4, 1, 3], [4, 5, 1, 4, 8, 3, 9, 2, 7]],
  [[0, 1, 3, 0, 0, 6, 8, 7, 0], [2, 0, 5, 0, 1, 7, 6, 0, 9], [0, 7, 6, 5, 0, 8, 0, 4, 1], [5, 2, 0, 0, 7, 0, 9, 0, 3], [6, 9, 7, 0, 4, 5, 2, 0, 0], [1, 0, 4, 6, 0, 0, 0, 5, 0], [0, 4, 0, 3, 5, 0, 1, 9, 0], [7, 0, 1, 8, 6, 0, 4, 3, 5], [9, 0, 8, 7, 0, 1, 5, 6, 0]],
  [[1, 0, 3, 0, 0, 6, 8, 0, 0], [2, 0, 5, 0, 1, 0, 0, 4, 0], [0, 7, 6, 0, 0, 0, 0, 0, 1], [5, 0, 0, 0, 7, 0, 0, 0, 3], [6, 0, 0, 0, 4, 0, 2, 0, 0], [1, 0, 4, 6, 0, 0, 0, 0, 0], [0, 4, 0, 0, 5, 0, 0, 9, 0], [7, 0, 1, 0, 0, 0, 4, 3, 5], [0, 0, 8, 7, 0, 1, 0, 6, 0]],
  [[0, 0, 0, 2, 6, 0, 7, 0, 1], [6, 8, 0, 0, 7, 0, 0, 9, 0], [1, 9, 0, 0, 0, 4, 5, 0, 0], [8, 2, 0, 1, 0, 0, 0, 4, 0], [0, 0, 4, 6, 0, 2, 9, 0, 0], [0, 5, 0, 0, 0, 3, 0, 2, 8], [0, 0, 9, 3, 0, 0, 0, 7, 4], [0, 4, 0, 0, 5, 0, 0, 3, 6], [7, 0, 3, 0, 1, 8, 0, 0, 0]],
  [[0, 0, 0, 6, 0, 0, 4, 0, 0], [7, 0, 0, 0, 0, 3, 6, 0, 0], [0, 0, 0, 0, 9, 1, 0, 8, 0], [0, 0, 0, 0, 0, 0, 0, 0, 2], [0, 0, 0, 0, 5, 0, 0, 0, 3], [9, 0, 3, 0, 0, 0, 0, 7, 0], [0, 0, 8, 0, 0, 0, 0, 0, 0], [0, 2, 0, 4, 1, 9, 0, 0, 5], [0, 0, 0, 0, 8, 0, 0, 7, 9]],
  [[0, 0, 0, 0, 2, 0, 0, 6, 3], [3, 0, 0, 0, 7, 0, 0, 0, 0], [9, 0, 1, 6, 0, 0, 5, 0, 0], [0, 0, 0, 0, 5, 1, 3, 0, 0], [8, 0, 0, 0, 0, 0, 0, 2, 4], [0, 0, 2, 7, 0, 0, 0, 0, 0], [0, 6, 0, 0, 0, 2, 4, 0, 8], [0, 0, 9, 0, 4, 0, 0, 0, 0], [4, 0, 0, 0, 1, 0, 0, 0, 0]],
  [[0, 1, 0, 0, 6, 0, 0, 0, 0], [9, 0, 0, 0, 0, 0, 0, 8, 4], [0, 0, 0, 8, 0, 4, 0, 0, 0], [0, 0, 6, 0, 0, 0, 0, 0, 3], [0, 4, 0, 0, 0, 0, 0, 0, 2], [8, 0, 0, 0, 0, 0, 4, 0, 0], [0, 0, 0, 6, 0, 7, 0, 0, 5], [4, 8, 0, 0, 0, 0, 0, 0, 0], [0, 0, 9, 0, 4, 0, 0, 0, 0]],
  [[0, 0, 0, 0, 8, 0, 0, 1, 0], [0, 0, 0, 9, 0, 0, 0, 0, 0], [6, 0, 0, 1, 0, 0, 0, 0, 0], [0, 4, 0, 0, 0, 0, 5, 0, 3], [0, 9, 0, 0, 2, 0, 0, 8, 0], [5, 0, 8, 0, 0, 0, 0, 2, 0], [0, 0, 0, 0, 0, 6, 0, 0, 4], [0, 0, 0, 0, 7, 0, 0, 0, 0], [3, 0, 0, 0, 0, 0, 0, 0, 0]],
  [[0, 0, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 2, 0, 0, 3], [5, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 6, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 7, 0], [0, 0, 8, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 3, 0, 0, 0, 0], [9, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 6, 0, 0]],
  [[0, 0, 5, 0, 0, 0, 0, 0, 0], [0, 3, 0, 0, 0, 1, 6, 0, 0], [0, 0, 8, 0, 2, 0, 0, 0, 0], [0, 0, 0, 0, 0, 5, 0, 0, 7], [0, 9, 0, 4, 0, 8, 0, 0, 0], [7, 0, 0, 9, 0, 0, 0, 0, 0], [0, 0, 0, 7, 0, 0, 4, 0, 0], [0, 0, 4, 0, 1, 0, 0, 9, 0], [0, 0, 0, 0, 0, 0, 5, 0, 0]],
  [[0, 0, 0, 0, 0, 6, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 7, 0], [0, 0, 0, 3, 0, 0, 0, 0, 0], [0, 0, 8, 0, 0, 0, 0, 0, 0], [5, 0, 0, 0, 0, 0, 0, 0, 4], [0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 2, 0, 0, 0], [0, 4, 0, 0, 0, 0, 0, 0, 9], [0, 0, 0, 7, 0, 0, 0, 0, 0]],
  [[0, 0, 0, 0, 6, 0, 0, 0, 3], [4, 0, 0, 0, 0, 0, 5, 0, 0], [0, 0, 0, 0, 0, 2, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 9, 0, 0, 0, 6, 0], [0, 0, 0, 0, 0, 0, 0, 0, 8], [0, 8, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 7, 0, 0, 5], [0, 0, 3, 0, 0, 0, 0, 0, 0]],
  [[0, 0, 0, 0, 0, 0, 0, 0, 5], [0, 1, 0, 0, 4, 0, 0, 0, 0], [0, 0, 0, 0, 3, 0, 0, 0, 0], [0, 0, 0, 9, 0, 0, 0, 0, 0], [6, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 2, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 5, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 8], [4, 0, 0, 0, 0, 0, 0, 0, 0]],
  [[0, 0, 0, 0, 8, 0, 0, 0, 0], [0, 0, 3, 0, 6, 0, 0, 0, 0], [0, 7, 0, 0, 0, 0, 0, 0, 0], [0, 5, 0, 0, 0, 0, 0, 0, 9], [0, 0, 0, 7, 0, 0, 0, 6, 0], [0, 0, 0, 0, 0, 3, 0, 0, 0], [0, 0, 2, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 9, 4]],
  [[0, 0, 0, 6, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 4, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 3, 0, 2, 0], [0, 0, 0, 0, 0, 0, 0, 5, 0], [0, 9, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 4, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 2]],
  [[0, 0, 0, 0, 0, 0, 0, 6, 0], [0, 3, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 6, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 7, 0, 0, 0], [0, 0, 0, 0, 3, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 5], [0, 0, 0, 0, 0, 0, 0, 0, 8], [7, 0, 0, 0, 0, 0, 0, 0, 0]],
  [[0, 0, 2, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 6, 0, 0, 0], [0, 0, 0, 0, 4, 0, 0, 0, 0], [0, 0, 0, 5, 0, 0, 0, 0, 0], [0, 0, 0, 0, 3, 0, 8, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 2, 0, 0, 0, 7], [3, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 4, 0, 0]],
  [[0, 0, 0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 3, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 7], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 6, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 4, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [5, 0, 0, 0, 0, 0, 0, 0, 0]],
  [[0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 4, 0, 0, 0, 0], [0, 0, 0, 0, 0, 5, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 6, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 2, 0], [0, 0, 0, 0, 0, 0, 0, 0, 8]]
];

function generarSudokuAleatorio() { 
  // Función para comprobar si se puede colocar un número en una celda 
  function esSeguro(tablero, fila, col, num) { 
    for (let x = 0; x < 9; x++) {
      if (tablero[fila][x] === num || tablero[x][col] === num || tablero[3 * Math.floor(fila / 3) + Math.floor(x / 3)][3 * Math.floor(col / 3) + x % 3] === num) {
        return false; 
      } 
    } 
    return true; 
  } 
  // Función para resolver el Sudoku utilizando Backtracking 
  function resolverSudoku(tablero) { 
    for (let fila = 0; fila < 9; fila++) { 
      for (let col = 0; col < 9; col++) { 
        if (tablero[fila][col] === 0) { 
          for (let num = 1; num <= 9; num++) { 
            if (esSeguro(tablero, fila, col, num)) { 
              tablero[fila][col] = num; 
              if (resolverSudoku(tablero)) { 
                return true; 
              } 
              tablero[fila][col] = 0; 
            } 
          } 
          return false; 
        } 
      } 
    } 
    return true; 
  } 
  let tablero = Array.from({ length: 9 }, () => Array(9).fill(0)); 
  resolverSudoku(tablero); 
  // Hacer aleatorio: remover algunos números 
  for (let i = 0; i < 40; i++) { 
    let fila = Math.floor(Math.random() * 9); 
    let col = Math.floor(Math.random() * 9); 
    tablero[fila][col] = 0; 
  } 
  return tablero; 
}

function createBoard(level) {
  gameBoard.innerHTML = '';
  level.forEach((row, rowIndex) => {
    row.forEach((num, colIndex) => {
      const cell = document.createElement('div');
      cell.classList.add('cell');
      if ((rowIndex + colIndex) % 3 === 0 && rowIndex !== 0 && colIndex !==0) {
        cell.classList.add('section');
      }

      cell.textContent = num === 0 ? '' : num;
      cell.contentEditable = num === 0;
      cell.addEventListener('input', handleInput);
      gameBoard.appendChild(cell);
    });
  });
}

function checkWin(level) {
  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      const cellValue = parseInt(gameBoard.children[i * 9 + j].textContent);
      if (isNaN(cellValue) || cellValue !== level[i][j]) {
        return false;
      }
    }
  }
  return true;
}

function handleInput(event) {
  const input = parseInt(event.target.textContent);
  if (isNaN(input) || input < 1 || input > 9) {
    event.target.textContent = '';
  }
}

function startGame(levelIndex) {
  currentLevel = levelIndex;
  createBoard(levels[levelIndex]);
}

function nextLevel() {
  if (currentLevel < levels.length - 1) {
    startGame(currentLevel + 1);
  } else {
    // Reinicia el juego al completar el último nivel
    alert("¡Felicidades! Has completado todos los niveles.\n(Entrando a El Laberinto del Azar)");
    createBoard(generarSudokuAleatorio());
  }
}

function handleWin() {
  if (checkWin(levels[currentLevel])) {
    alert("¡Nivel completado!");
    nextLevel();
  }
}

// Agregar un evento para verificar la victoria cada vez que se modifica una celda
gameBoard.addEventListener('input', handleWin);

for (let i = 0; i < levels.length; i++) {
  const button = document.createElement('button');
  button.textContent = `Nivel ${i + 1}`;
  button.addEventListener('click', () => startGame(i));
  levelSelect.appendChild(button);
}

startGame(0); // inicia en el nivel 1 por defecto
